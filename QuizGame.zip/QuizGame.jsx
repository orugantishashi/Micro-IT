import React, { useState } from "react";
import "./QuizGame.css";

const questions = [
    {
        question: "What is the capital of France?",
        options: ["Paris", "Madrid", "Rome", "Berlin"],
        answer: "Paris",
    },
    {
        question: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        answer: "4",
    },
    {
        question: "React is a ___?",
        options: ["Library", "Framework", "Language", "Tool"],
        answer: "Library",
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: ["Earth", "Mars", "Jupiter", "Venus"],
        answer: "Mars",
    },
    {
        question: "What does CSS stand for?",
        options: [
            "Computer Style Sheets",
            "Creative Style Sheets",
            "Cascading Style Sheets",
            "Colorful Style Sheets",
        ],
        answer: "Cascading Style Sheets",
    },
    {
        question: "Which language runs in a web browser?",
        options: ["Java", "C", "Python", "JavaScript"],
        answer: "JavaScript",
    },
    {
        question: "What does HTML stand for?",
        options: [
            "HyperText Markup Language",
            "Hyper Tool Markup Language",
            "Hyperlinking Text Main Language",
            "Home Tool Markup Language",
        ],
        answer: "HyperText Markup Language",
    },
    {
        question: "Which company developed React?",
        options: ["Google", "Facebook", "Microsoft", "Amazon"],
        answer: "Facebook",
    },
    {
        question: "What is useState in React used for?",
        options: [
            "To store CSS",
            "To fetch APIs",
            "To manage state",
            "To handle routing",
        ],
        answer: "To manage state",
    },
    {
        question: "Which HTML tag is used for large headings?",
        options: ["<head>", "<h1>", "<heading>", "<title>"],
        answer: "<h1>",
    },
];

const QuizGame = () => {
    const [current, setCurrent] = useState(0);
    const [score, setScore] = useState(0);
    const [selected, setSelected] = useState("");
    const [showResult, setShowResult] = useState(false);
    const [submitted, setSubmitted] = useState(false);

    const currentQuestion = questions[current];

    const handleSubmit = () => {
        if (selected === currentQuestion.answer) {
            setScore((prev) => prev + 1);
        }
        setSubmitted(true);
    };

    const handleNext = () => {
        setSubmitted(false);
        setSelected("");
        if (current + 1 < questions.length) {
            setCurrent((prev) => prev + 1);
        } else {
            setShowResult(true);
        }
    };

    const restartQuiz = () => {
        setCurrent(0);
        setScore(0);
        setSelected("");
        setShowResult(false);
        setSubmitted(false);
    };

    const getOptionClass = (option) => {
        if (!submitted) {
            return selected === option ? "option selected" : "option";
        }
        if (option === currentQuestion.answer) return "option correct";
        if (option === selected) return "option wrong";
        return "option";
    };

    return (
        <div className="quiz-container">
            <div className="quiz-box">
                <h1 className="title">Quiz Game</h1>

                {showResult ? (
                    <div className="result-box">
                        <h2>🎉 Quiz Completed!</h2>
                        <p>Your Score: {score} / {questions.length}</p>
                        <button onClick={restartQuiz} className="btn green">Restart</button>
                    </div>
                ) : (
                    <>
                        <div className="question-info">
                            <p>Question {current + 1} of {questions.length}</p>
                            <h3>{currentQuestion.question}</h3>
                        </div>

                        <div className="options">
                            {currentQuestion.options.map((option) => (
                                <label key={option} className={getOptionClass(option)}>
                                    <input
                                        type="radio"
                                        name="option"
                                        value={option}
                                        checked={selected === option}
                                        disabled={submitted}
                                        onChange={() => setSelected(option)}
                                    />
                                    {option}
                                </label>
                            ))}
                        </div>

                        {!submitted ? (
                            <button
                                className="btn blue"
                                disabled={!selected}
                                onClick={handleSubmit}
                            >
                                Submit
                            </button>
                        ) : (
                            <button className="btn blue" onClick={handleNext}>
                                {current + 1 === questions.length ? "Finish" : "Next"}
                            </button>
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

export default QuizGame;