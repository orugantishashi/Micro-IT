import Quiz from "./QuizGame"
export default function App() {
  return (
    <>
      <QuizGame/>
    </>
  )
}